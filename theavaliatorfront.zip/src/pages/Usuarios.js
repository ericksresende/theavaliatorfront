import React from 'react';
import { Box, Container, ListItem, ListItemText, ListItemButton } from '@mui/material';
import Styles from '../pages/css/Base.module.css';
import Navbar from './components/Navbar';
import { FixedSizeList } from 'react-window';
import User from '../services/UsersQuizz';
import Problem from '../services/Problem';
import Submission from '../services/Submission';
import SubmissionTeacher from '../services/SubmissionTeacher';
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import AccountBoxIcon from '@mui/icons-material/AccountBox';
import SendIcon from '@mui/icons-material/Send';

const Usuarios = () => {
  
  // Lista de usuários
  const [userData, setUserData] = useState([]);
  const arraySubmissoesAluno = [];

  // Puxando as variáveis do sessionStorage
  const token = sessionStorage.getItem('token');
  const idtarefa = sessionStorage.getItem('idtarefa');
  const nometarefa = sessionStorage.getItem('nometarefa');
  const datalimite = sessionStorage.getItem('datalimite');

  // Instanciando o serviço de Usuário
  const user = new User(token, idtarefa);

  // Instanciando o serviço de navegação
  const navigate = useNavigate();

  // Função de navegar para a tela de problemas
  function acessarSubmissoes(id, title) {
    sessionStorage.setItem("idusuario", id);
    console.log(idtarefa);
    navigate("/problemas");
  }

  // Função de puxar a lista de usuários
  useEffect(() => {
    user.getUsers()
      .then((data) => {
        setUserData(data);
      });
  }, []);

  async function obterSubmissoes(dataproblems, idusuario, datalimite) {
    const submissoesAlunoAtual = [];
    console.log("ENTROU");
    console.log(dataproblems);
    dataproblems.problems.map(async ({ id, filename }) => {
      const submission = new Submission(token, id , idusuario, datalimite);
      const submissiondata = await submission.getSubmissions().then((data) => {
        // Filtrar as submissões corretas
        const correctSubmissions = data.filter(({ evaluation }) => evaluation === "CORRECT");
        
        if (correctSubmissions.length === 0) {
          // Não há submissões corretas, faça algo apropriado aqui
          return;
        }
        
        // Encontrar o máximo número de tentativas entre as submissões corretas
        const maxTries = Math.max(...correctSubmissions.map(({ tries }) => tries));
        
        // Filtrar as submissões que são "CORRECT" e têm o maior número de tentativas
        const bestSubmissions = correctSubmissions.filter(({ tries }) => tries === maxTries);
        
        // Agora você tem `bestSubmissions` com as submissões corretas que têm o maior número de tentativas.
        // Você pode usá-lo conforme necessário.
        submissoesAlunoAtual.push(bestSubmissions);
      });
    });
    arraySubmissoesAluno.push(submissoesAlunoAtual);
    console.log(arraySubmissoesAluno);
  }

  async function obterSubmissoesProfessor(data) {
    console.log(data);
    const arraySubmissoesProfessor = [];
    
    // Use Promise.all para aguardar todas as chamadas assíncronas
    await Promise.all(data.map(async ({ id }) => {
      const submissionteacher = new SubmissionTeacher(token, id);
      const submissions = await submissionteacher.getSubmissions();
      arraySubmissoesProfessor.push(submissions);
    }));
    
    // Serialize os dados em JSON antes de salvá-los no sessionStorage
    const serializedData = JSON.stringify(arraySubmissoesProfessor);
    console.log(arraySubmissoesProfessor);
    sessionStorage.setItem("codigosProfessor", serializedData);
  }

  useEffect(() => {
    console.log("ENTROU");
    userData.map(async ({id}) => {
      const problems = new Problem(token, idtarefa, id);
      await problems.getProblems().then((data) => {
        // console.log("bora");
        console.log(data.problems);
        sessionStorage.setItem("arrayProblemas", JSON.stringify(data.problems));
        obterSubmissoes(data, id, datalimite);
      })
      .catch(error => console.log("VEJA AQUI BELEZA" + error));
    });
    
    // Recupere a string JSON do sessionStorage
    const jsonString = sessionStorage.getItem("arrayProblemas");
    
    // Converta a string de volta para um array JSON
    const jsonArray = JSON.parse(jsonString);
    
    // Agora você pode acessar jsonArray como um array JSON
    console.log(jsonArray);
    obterSubmissoesProfessor(jsonArray);
  }, []);

  return (
    <React.Fragment>
      <Navbar />
      <Container style={{
        width: "100vw",
        height: "100vh",
        background: "white",
        alignItems: "center",
      }}>
        <h2>Lista de Alunos da tarefa {nometarefa}</h2>
        <br></br>
        <Box>
          <Box style={{
            background: "#243856",
            padding: "20px",
            borderRadius: '10px',
            borderBottomLeftRadius: '0',
            borderBottomRightRadius: '0',
            border: "1px solid black",
          }}>
          </Box>
          <div>
            {userData.map(({ id, name}) => (
              <ListItem key={id} component="div" disablePadding secondaryAction={<ListItemButton component="a" onClick={() => acessarSubmissoes(id, token)}>
                <SendIcon />
              </ListItemButton>} style={{ padding: "5px",
                borderBottom: "1px solid black", borderLeft: "1px solid black", borderRight: "1px solid black",
              }}>
                <AccountBoxIcon />
                <ListItemText primary={name} style={{ marginLeft: "5px" }} />
              </ListItem>
            ))}
          </div>
        </Box>
      </Container>
    </React.Fragment>
  );
}

export default Usuarios;
