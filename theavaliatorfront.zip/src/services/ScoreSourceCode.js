/* eslint-disable eqeqeq */
import axios from 'axios';

class ScoreSourceCode {
  constructor(idproblema, idsubmissaoaluno, codigoAluno, codigoProfessor, nomeProblema) {
    this.urlsource = 'https://avaliador.guugascode.site/avaliarsubmissoes';
    this.configsource = {
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        }
      };
    this.jsonData = {
      id: idproblema,
      alunos: [
        {id: idsubmissaoaluno, codigo: codigoAluno},
      ],
      professor: codigoProfessor,
      problema: nomeProblema
    };
    this.jsonString = JSON.stringify(this.jsonData);
    
    console.log(this.jsonData);
}   

async getScore() {
    try {
      console.log("TA AQUI");
      console.log(this.jsonString);
      const response = await axios.post(this.urlsource, this.jsonData);
      console.log('Resposta:', response.data);
      return response.data;
    } catch (error) {
      console.log(error);
      throw error; // Lança o erro para ser tratado em níveis superiores
    }
  }
  

  // async obter(evaluations, max = '10', offset = '0', order = 'desc', problemId, sort = 'submissionDate', submissionDateGe, submissionDateLe) {
  //   let queryParams = [];

  //   if (evaluations) {
  //     queryParams.push(`evaluations=${evaluations}`);
  //   }

  //   queryParams.push(`max=${max}`);
  //   queryParams.push(`offset=${offset}`);
  //   queryParams.push(`order=${order}`);

  //   if (problemId) {
  //     queryParams.push(`problem=${problemId}`);
  //   }

  //   queryParams.push(`sort=${sort}`);

  //   if (submissionDateGe) {
  //     queryParams.push(`submissionDateGe=${submissionDateGe}`);
  //   }

  //   if (submissionDateLe) {
  //     queryParams.push(`submissionDateLe=${submissionDateLe}`);
  //   }

  //   const queryString = queryParams.join('&');
  //   const requestUrl = `${this.url}?${queryString}`;

  //   console.log(requestUrl);
  //   return axios.get(requestUrl, this.config);
  // }    
}

export default ScoreSourceCode;
